rootProject.name = "drone-service"

